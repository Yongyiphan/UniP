// make sure to add file-level documentation here!!!

//-------------------------------------------------------------------------
#ifndef FT_H
#define FT_H
//-------------------------------------------------------------------------
#include <iostream>
// Do not add any other header files. Otherwise, your submission
// will not compile!!!

namespace hlp2 {
// DECLARE (not define!!!) and DOCUMENT in ALPHABETIC ORDER the function
// templates you'll be defining. There are *13* function templates to be
// declared and defined.
  
// I'm providing the declaration and documentation for swap here:
/***************************************************************************/
/*!
\brief
 Swaps two objects. There is no return value but the two objects are
 swapped in place.

\param lhs
  Reference to the first object to swap.

\param rhs
 Reference to the second object to swap.
*/
/**************************************************************************/
  
// Provide DEFINITIONS for each function template declared above ...

template <typename I> I*     copy(const I* start, const I* end, I* dst);
template <typename I> I*     copy(const I* start, const I* end, I* dst){
  for(; start < end; *dst = *start, ++dst, ++start);
  return dst;
}

template <typename I, typename T> int   count( I  start, I  end, T value);
template <typename I, typename T> int   count( I  start, I  end, T value){
  int c{};
  for(; start < end; ++start)
    if(*start == value)
      c++;
  
  return c;
}

template <typename I>             void  display(const I* start, const I* end);
template <typename I>             void  display(const I* start, const I* end){
  while(start < end){
    std::cout << *start;
    if(++start != end)
      std::cout << ", ";
  }
  std::cout << std::endl;
}

template <typename I, typename T> bool  equal(  I* start1,  I* end1,  T* start2);
template <typename I, typename T> bool  equal(  I* start1,  I* end1,  T* start2){
  for(;start1 < end1; ++start1, ++start2){
    if(*start1 != *start2)
      return false;
  }
  return true;
}

template <typename I, typename T> void  fill( I*  start, I* end, T value);
template <typename I, typename T> void  fill( I*  start, I* end, T value){
  for(;start < end; ++start)
    *start = value;
}

template <typename I, typename T> I*     find( I*  start, I* end, T value);
template <typename I, typename T> I*     find( I*  start, I* end, T value){
  for(;start < end; ++start)
    if(*start == value)
      return start;

  return start;
}

template <typename I>             I*     max_element( I* start,  I* end);
template <typename I>             I*     max_element( I* start,  I* end){
  I* m = start;
  for(; start < end; ++start){
    if(*start < *m){
      continue;
    }
    m = start;
  }
  return m;
}

template <typename I>             I*     min_element( I* start,  I* end);
template <typename I>             I*     min_element( I* start,  I* end){
  I* m = start;
  for(; start < end; ++start){
    if(*start < *m)
      m = start;
  }
  return m;
}

template <typename I, typename T> I*     remove( I* start, I* end, T value);
template <typename I, typename T> I*     remove( I* start, I* end, T value){
  I* newEnd = start;
  for(; start < end; ++start){
    if(*start == value) continue;
    *newEnd = *start;
    ++newEnd;
  }
  return newEnd;
}

template <typename I, typename T> void  replace( I*  start, I*  end, T oitem, T nitem);
template <typename I, typename T> void  replace( I*  start, I*  end, T oitem, T nitem){
  for(; start < end; ++start)
    if(*start == oitem)
      *start = nitem;
}

template <typename T> T     sum( T* start,  T* end);
template <typename T> T     sum( T* start,  T* end){
  T total{};
  for(;start < end; total += *start, ++start);
  return total;
}

template <typename T>             void  swap(T &lhs, T &rhs);
template <typename T>             void  swap(T &lhs, T &rhs){
  T temp = lhs;
  lhs = rhs;
  rhs = temp;
}

template <typename I>             void  swap_ranges( I* start1,  I* end1,  I* start2);
template <typename I>             void  swap_ranges( I* start1,  I* end1,  I* start2){
  for(;start1 < end1; ++start1, ++start2){
    swap(*start1, *start2);
  }
}





}

#endif
//-------------------------------------------------------------------------
