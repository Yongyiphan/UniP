#ifndef Q_HPP_
#define Q_HPP_

// Important note:
// If there any includes in this file, the auto grade will not
// accept the submission.

namespace hlp2 {
  // declare function q here ...
}

#endif
