#include "pch.h"

#include "Level1.h"

void Level1_Load()
{
	//some code here
}

void Level1_Initialize()
{
	//some code here
}

void Level1_Update()
{
	//some code here
}

void Level1_Draw()
{
	//some code here
}

void Level1_Free()
{
	//some code here
}

void Level1_Unload()
{
	//some code here
}