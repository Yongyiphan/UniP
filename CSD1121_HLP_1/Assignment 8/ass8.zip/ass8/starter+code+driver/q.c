// TODO: File documentation block required

// NOTE 2: Even if you don't need the NULL, don't remove this macro ...
#define NULL ((void*)0) 

// NOTE 3: When uploading this file for grading, make sure to remove all
// standard library includes from this file.
// The auto-grader will not accept your submission if the file contains
// include directives.

// NOTE 4: When uploading this file for grading, make sure to remove
// all references to the subscript operator or the [ or ] symbols from your code. 
// It is important that even your comments should not include these symbols.

// TODO: Definitions of functions declared in q.h go here ...
